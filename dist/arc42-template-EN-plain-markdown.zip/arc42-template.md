About arc42
===========

arc42, the Template for documentation of software and system
architecture.

By Dr. Gernot Starke, Dr. Peter Hruschka and contributors.

Template Revision: 6.5 EN (asciidoc-basiert), Juni 2014

© We acknowledge that this document uses material from the arc 42
architecture template, <http://www.arc42.de>. Created by Dr. Peter
Hruschka & Dr. Gernot Starke. For additional contributors see
<http://arc42.de/sonstiges/contributors.html>

> **Note**
>
> This version of the template contains some help and explanations. It
> is used for familiarization with arc42 and the understanding of the
> concepts. For documentation of your own system you use better the
> *plain* version.

Introduction and Goals
======================

The introduction to the architecture documentation should list the
driving forces that software architects must consider in their
decisions. This includes on the one hand the fulfillment of functional
requirements of the stakeholders, on the other hand the fulfillment of
or compliance with required constraints, always in consideration of the
architecture goals.

Requirements Overview
---------------------

Quality Goals
-------------

Stakeholders
------------

Architecture Constraints
========================

Technical Constraints
---------------------

+----------------+-----------------------------------------------------------+
| Technical      |
| Constraints    |
+================+===========================================================+
| *Hardware      |
| Constraints*   |
+----------------+-----------------------------------------------------------+
| C1             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C2             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C3             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| *Software      |
| Constraints*   |
+----------------+-----------------------------------------------------------+
| C4             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C5             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C6             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| *Operating     |
| System         |
| Constraints*   |
+----------------+-----------------------------------------------------------+
| C7             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C8             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C9             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| *Programming   |
| Constraints*   |
+----------------+-----------------------------------------------------------+
| C10            | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C11            | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C12            | insert description here                                   |
+----------------+-----------------------------------------------------------+

: List of Technical Constraints

Organizational Constraints
--------------------------

+----------------+-----------------------------------------------------------+
| Organizational |
| Constraints    |
+================+===========================================================+
| *Organization  |
| and Structure* |
+----------------+-----------------------------------------------------------+
| C1             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C2             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| *Resources     |
| (Budget, Time, |
| Personnel)*    |
+----------------+-----------------------------------------------------------+
| C3             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C4             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| *Organizationa |
| l              |
| Standards*     |
+----------------+-----------------------------------------------------------+
| C5             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C6             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| *Legal         |
| Factors*       |
+----------------+-----------------------------------------------------------+
| C7             | insert description here                                   |
+----------------+-----------------------------------------------------------+
| C8             | insert description here                                   |
+----------------+-----------------------------------------------------------+

: List of Organizational Constraints

Conventions
-----------

System Scope and Context
========================

Business Context
----------------

Technical Context
-----------------

External Interfaces
-------------------

Solution Strategy
=================

Building Block View
===================

Level 1
-------

The following diagram shows the main building blocks of the system and
their interdependencies:

\<insert overview diagram here\>

Comments regarding structure and interdependencies at Level 1:

### Building Block Name 1 (Black Box Description)

\<insert the building block’s black box template here\>

### Building Block Name 2 (Black Box Description)

\<insert the building block’s black box template here\>

### …

\<insert the building block’s black box template here\>

### Building Block Name n (Black Box Description)

\<insert the building block’s black box template here\>

### Open Issues

Level 2
-------

### Building Block Name 1 (White Box Description)

\<insert diagram of building block 1 here\>

#### Building Block Name 1.1 (Black Box Description)

#### Building Block Name 1.2 (Black Box Description)

Structure according to black box template

#### …

#### Building Block Name 1.n (Black Box Description)

#### Description of Relationships

#### Open Issues

### Building Block Name 2 (White Box Description)

…

\<insert diagram of building block 2 here\>

#### Building Block Name 2.1 (Black Box Description)

Structure according to black box template

#### Building Block Name 2.2 (Black Box Description)

#### …

#### Building Block Name 2.n (Black Box Description)

#### Description of Relationships

#### Open Issues

### Building Block Name 3 (White Box Description)

…

\<insert diagram of building block 3 here\>

#### Building Block Name 3.1 (Black Box Description)

#### Building Block Name 3.2 (Black Box Description)

#### …

#### Building Block Name 3.n (Black Box Description)

#### Description of Relationships

#### Open Issues

Level 3
-------

Runtime View
============

Runtime Scenario 1
------------------

Runtime Scenario 2
------------------

…
-

some more

Runtime Scenario n
------------------

Deployment View
===============

Infrastructure Level 1
----------------------

### Deployment Diagram Level 1

### Processor 1

\<insert node template here\>

### Processor 2

\<insert node template here\>

### …

### Processor n

\<insert node template here\>

### Channel 1

### Channel 2

### …

### Channel m

Infrastructure Level 2
----------------------

Concepts
========

Domain Models
-------------

Recurring or Generic Structures and Patterns
--------------------------------------------

### ecurring or Generic Structure 1

\<insert diagram and descriptions here\>

### Recurring or Generic Structure 2

\<insert diagram and descriptions here\>

Persistency
-----------

User Interface
--------------

Ergonomics
----------

Flow of Control
---------------

Transaction Procession
----------------------

Session Handling
----------------

Security
--------

Safety
------

Communications and Integration
------------------------------

Distribution
------------

Plausibility and Validity Checks
--------------------------------

Exception/Error Handling
------------------------

System Management and Administration
------------------------------------

Logging, Tracing
----------------

Business Rules
--------------

Configurability
---------------

Parallelization and Threading
-----------------------------

Internationalization
--------------------

Migration
---------

Testability
-----------

Scaling, Clustering
-------------------

High Availability
-----------------

Code Generation
---------------

Build-Management
----------------

Design Decisions
================

Decision Topic Template
-----------------------

Decision Topic 1
----------------

**Decision.**

+

Decision Topic 2
----------------

+

Decision Topic 3
----------------

+

…
-

+

Quality Scenarios
=================

Quality Tree
------------

Evaluation Scenarios
--------------------

Technical Risks
===============

Glossary
========

+--------------------+--------------------+--------------------+--------------------+
| Glossary           |                    |                    |                    |
+====================+====================+====================+====================+
| Term               | Synonym            | Description        |                    |
+--------------------+--------------------+--------------------+--------------------+
| Term               | Synonym            | Description        |                    |
+--------------------+--------------------+--------------------+--------------------+

Literature and references
=========================

Starke-2014
:   Gernot Starke: Effektive Softwarearchitekturen - Ein praktischer
    Leitfaden. Carl Hanser Verlag, 6, Auflage 2014.

Starke-Hruschka-2011
:   Gernot Starke und Peter Hruschka: Softwarearchitektur kompakt.
    Springer Akademischer Verlag, 2. Auflage 2011.

Zörner-2013
:   Softwarearchitekturen dokumentieren und kommunizieren, Carl Hanser
    Verlag, 2012

Examples
========

-   [HTML Sanity
    Checker](http://aim42.github.io/htmlSanityCheck/hsc_arc42.html)

-   [DocChess](http://www.dokchess.de/dokchess/arc42/) (german)

-   [Gradle](http://www.embarc.de/arc42-starschnitt-gradle/) (german)

-   [MaMa CRM](http://arc42.org:8090/display/arc42beispielmamacrm)
    (german)

-   [Financial Data
    Migration](http://confluence.arc42.org/display/migrationEg/Financial+Data+Migration)
    (german)

Acknowledgements and collaborations
===================================

arc42 originally envisioned by [Dr. Peter Hruschka](http://b-agile.de)
and [Dr. Gernot Starke](http://gernotstarke.de).

Sources
:   We maintain arc42 in *asciidoc* format at the moment, hosted in
    [GitHub under the
    aim42-Organisation](https://github.com/aim42/aim42).

Issues
:   We maintain a list of [open topics and
    bugs](https://github.com/arc42/arc42-template/issues).

We are looking forward to your corrections and clarifications! Please
fork the repository mentioned over this lines and send us a *pull
request*!

Collaborators
-------------

We are very thankful and acknowledge the support and help provided by
all active and former collaborators, uncountable (anonymous) advisors,
bug finders and users of this method.

### Currently active

-   Gernot Starke

-   Stefan Zörner

-   Markus Schärtel

-   Ralf D. Müller

-   Peter Hruschka

-   Jürgen Krey

### Former collaborators

(in alphabetical order)

-   Anne Aloysius

-   Matthias Bohlen

-   Karl Eilebrecht

-   Manfred Ferken

-   Phillip Ghadir

-   Carsten Klein

-   Prof. Arne Koschel

-   Axel Scheithauer

Approved Practitioner for arc42
===============================

(TODO)

