*Bausteinname* Whitebox

Übersicht / Struktur
:   *Die folgende Abbildung zeigt die inneren Bestandteile von
    \_Bausteinname* und deren Abhängigkeiten.

*\<hier Überblicksdiagramm einfügen\>*

Begründung
:   *Begründen oder erläutern Sie die Struktur*

Enthaltene Bausteine
:   *hier beschreiben Sie (kurz) Name und Zweck der enhaltenen
    Bausteine*

+-------------+--------------------------------------------------+-------------+
| Baustein 1  | Beschreibung 1                                   | Verweis auf |
|             |                                                  | Blackbox-Be |
|             |                                                  | schreibung  |
+-------------+--------------------------------------------------+-------------+
| Baustein 2  |  Beschreibung 2                                  | Verweis auf |
|             |                                                  | Blackbox-Be |
|             |                                                  | schreibung  |
+-------------+--------------------------------------------------+-------------+
| Baustein 3  | Beschreibung 3                                   | Verweis auf |
|             |                                                  | Blackbox-Be |
|             |                                                  | schreibung  |
+-------------+--------------------------------------------------+-------------+

Schnittstellen
:   *hier beschreiben Sie (kurz) Name und Zweck der (internen+externen)
    Schnittstellen der Bausteine.*

+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 1                                            |
| 1              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  |  Beschreibung 2                                           |
| 2              |                                                           |
+----------------+-----------------------------------------------------------+
| Schnittstelle  | Beschreibung 3                                            |
| 3              |                                                           |
+----------------+-----------------------------------------------------------+


