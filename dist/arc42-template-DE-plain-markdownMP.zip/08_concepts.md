Konzepte
========

Fachliche Strukturen und Modelle
--------------------------------

Typische Muster und Strukturen
------------------------------

Persistenz
----------

Benutzungsoberfläche
--------------------

Ergonomie
---------

Ablaufsteuerung
---------------

Transaktionsbehandlung
----------------------

Sessionbehandlung
-----------------

Sicherheit
----------

Kommunikation und Integration mit anderen IT-Systemen
-----------------------------------------------------

Verteilung
----------

Plausibilisierung und Validierung
---------------------------------

Ausnahme-/Fehlerbehandlung
--------------------------

Management des Systems & Administrierbarkeit
--------------------------------------------

Logging, Protokollierung, Tracing
---------------------------------

Geschäftsregeln
---------------

Konfigurierbarkeit
------------------

Parallelisierung und Threading
------------------------------

Internationalisierung
---------------------

Migration
---------

Testbarkeit
-----------

Skalierung, Clustering
----------------------

Hochverfügbarkeit
-----------------

Codegenerierung
---------------

Buildmanagement
---------------

Stapel-/Batchverarbeitung
-------------------------

Drucken
-------

Reporting
---------

Archivierung
------------
