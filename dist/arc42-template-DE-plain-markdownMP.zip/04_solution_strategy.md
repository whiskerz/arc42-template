Lösungsstrategie
================
