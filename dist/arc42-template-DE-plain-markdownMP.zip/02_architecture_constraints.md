Randbedingungen
===============

(engl.: Architecture Constraints)

Technische Randbedingungen
--------------------------

+-------------------------+-------------------------------------------------+
| Hardware-Vorgaben       |
+=========================+=================================================+
|                         | *Randbedingung~1~*                              |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~2~*                              |
+-------------------------+-------------------------------------------------+
| **Software-Vorgaben**   |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~i~*                              |
+-------------------------+-------------------------------------------------+
| **Vorgaben des          |
| Systembetriebs**        |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~j~*                              |
+-------------------------+-------------------------------------------------+
| **Programmiervorgaben** |
+-------------------------+-------------------------------------------------+
|                         | *Randbedingung~k~*                              |
+-------------------------+-------------------------------------------------+

: Technische Randbedingungen

Organisatorische Randbedingungen
--------------------------------

### Organisation und Struktur

*\<hier Randbedingungen einfügen\>*

### Ressourcen (Budget, Zeit, Personal)

*\<hier Randbedingungen einfügen\>*

### Organisatorische Standards

*\<hier Randbedingungen einfügen\>*

### Juristische Faktoren

*\<hier Randbedingungen einfügen\>*

Konventionen
------------
