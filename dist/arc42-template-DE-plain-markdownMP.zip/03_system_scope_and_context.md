Kontextabgrenzung
=================

Die folgenden Unterkapitel zeigen die Einbettung unseres Systems in
seine Umgebung.

Fachlicher Kontext
------------------

Technischer- oder Verteilungskontext
------------------------------------

Externe Schnittstellen
----------------------
