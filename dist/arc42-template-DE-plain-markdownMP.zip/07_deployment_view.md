Verteilungssicht
================

Infrastruktur Ebene 1
---------------------

### Verteilungsdiagramm Ebene 1

### Prozessor 1

### Prozessor 2

…

### Prozessor *n*

### Kanal 1

### Kanal 2

…

### Kanal *m*

### Offene Punkte

Infrastruktur Ebene 2
---------------------
