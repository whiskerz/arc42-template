Solution Strategy
=================
