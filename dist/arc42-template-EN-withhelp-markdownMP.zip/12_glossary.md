Glossary
========

**Contents.**

The most important terms of the software architecture in alphabetic
order.

**Motivation.**

It should not be necessary to explain the usefulness of a glossary …

**Form.**

A simple table with columns \<Term\> and \<Definition\>

+--------------------+--------------------+--------------------+--------------------+
| Glossary           |                    |                    |                    |
+====================+====================+====================+====================+
| Term               | Synonym            | Description        |                    |
+--------------------+--------------------+--------------------+--------------------+
| Term               | Synonym            | Description        |                    |
+--------------------+--------------------+--------------------+--------------------+


