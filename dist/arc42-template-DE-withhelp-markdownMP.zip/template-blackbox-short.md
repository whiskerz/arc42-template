*Bausteinname* Blackboxbeschreibung

**Zweck:** *hier beschreiben Sie Zweck oder Verantwortung des Bausteins*

+-------------------------+-------------------------------------------------+
| Schnittstelle 1         | Beschreibung 1                                  |
+-------------------------+-------------------------------------------------+
| Schnittstelle 2         |  Beschreibung 2                                 |
+-------------------------+-------------------------------------------------+
| Schnittstelle 3         | Beschreibung 3                                  |
+-------------------------+-------------------------------------------------+

: Schnittstellen *Bausteinname*:

**Ablageort/Datei:** *Verweisen Sie auf den Einstieg in den Sourcecode,
den/die Paket-/Modulnamen oder die wichtigsten Klassen*

