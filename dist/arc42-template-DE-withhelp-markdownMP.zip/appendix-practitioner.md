Approved Practitioner for arc42
===============================

(TODO)

