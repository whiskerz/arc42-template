Risiken
=======

**Inhalt.**

Eine nach Prioritäten geordnete Liste der erkannten technischen Risiken

**Motivation.**

"Risikomanagement ist Projektmanagement für Erwachsene" (Tim Lister,
Atlantic Systems Guild.) Unter diesem Motto sollten Sie technische
Risiken in der Architektur gezielt ermitteln, bewerten und dem
Projektmanagement als Teil der gesamten Risikoanalyse zur Verfügung
stellen.

**Form.**

Risikolisten mit Eintrittswahrscheinlichkeit, Schadenshöhe, Maßnahmen
zur Risikovermeidung oder Risikominimierung, …

+-------------------------+-------------------------------------------------+
| Risiko                  | Priorität                                       |
+=========================+=================================================+
| Konsequenz              | Erläuterung                                     |
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+
+-------------------------+-------------------------------------------------+

: Risiken


